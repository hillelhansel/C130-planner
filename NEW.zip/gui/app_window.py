# gui/app_window.py
import customtkinter as ctk
from gui.navigation.main_menu import MainMenu
from gui.planner.mission_screen import MissionScreen
from services.mission_manager import MissionManager

class AppWindow(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        # הגדרות חלון בסיסיות
        self.title("C-130J Mission Planner (Refactored)")
        self.geometry("1200x800")
        ctk.set_appearance_mode("Dark")
        ctk.set_default_color_theme("blue")
        
        # === יצירת המוח של המערכת (פעם אחת בלבד!) ===
        # זה האובייקט שיחזיק את כל הנתונים ויעבור בין המסכים
        self.mission_manager = MissionManager()
        
        # קונטיינר ראשי
        self.container = ctk.CTkFrame(self, fg_color="transparent")
        self.container.pack(fill="both", expand=True)
        
        # הפעלה ראשונית - הצגת התפריט
        self.show_menu()

    def clear_frame(self):
        """מנקה את המסך הנוכחי"""
        for widget in self.container.winfo_children():
            widget.destroy()

    def show_menu(self):
        """מציג את התפריט הראשי"""
        self.clear_frame()
        MainMenu(self.container, self.show_planner, self.show_fleet).pack(fill="both", expand=True)

    def show_planner(self):
        """מציג את מסך התכנון"""
        self.clear_frame()
        # אנחנו מזריקים את המנהל הקיים למסך החדש
        MissionScreen(self.container, self.mission_manager, self.show_menu).pack(fill="both", expand=True)

    def show_fleet(self):
        """מציג את מסך ניהול הצי"""
        self.clear_frame()
        # טעינת המסך האמיתי מתוך הקובץ החדש
        from gui.fleet.fleet_screen import FleetScreen
        FleetScreen(self.container, self.show_menu).pack(fill="both", expand=True)