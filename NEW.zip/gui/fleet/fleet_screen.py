import customtkinter as ctk
from services.data_service import DataService

class ExcelTable(ctk.CTkFrame):
    def __init__(self, parent, headers, widths):
        super().__init__(parent, fg_color="transparent")
        self.headers = headers
        self.widths = widths
        
        # כותרות
        h_frame = ctk.CTkFrame(self, fg_color="#444", height=28)
        h_frame.pack(fill="x", pady=(0, 2))
        for i, txt in enumerate(headers):
            ctk.CTkLabel(h_frame, text=txt, width=widths[i], font=("Arial", 11, "bold"), text_color="white").pack(side="left", padx=1)

        # גוף הטבלה
        self.scroll = ctk.CTkScrollableFrame(self, fg_color="#2b2b2b")
        self.scroll.pack(fill="both", expand=True)

    def set_data(self, rows_data, callback=None):
        for w in self.scroll.winfo_children(): w.destroy()
        
        for row in rows_data:
            values = row.get("values", [])
            colors = row.get("colors", ["white"] * len(values))
            ref = row.get("ref", None)
            
            f = ctk.CTkFrame(self.scroll, fg_color="transparent", height=25)
            f.pack(fill="x", pady=1)
            
            for i, val in enumerate(values):
                w = self.widths[i]
                # עמודת עריכה (אינדקס 3 - "בפועל")
                if callback and i == 3: 
                    cf = ctk.CTkFrame(f, fg_color="transparent", width=w)
                    cf.pack(side="left", padx=1)
                    ctk.CTkButton(cf, text="-", width=20, height=20, fg_color="#555", command=lambda r=ref: callback(r, -1)).pack(side="left")
                    ctk.CTkLabel(cf, text=str(val), width=20).pack(side="left")
                    ctk.CTkButton(cf, text="+", width=20, height=20, fg_color="#555", command=lambda r=ref: callback(r, 1)).pack(side="left")
                else:
                    ctk.CTkLabel(f, text=str(val), width=w, text_color=colors[i], anchor="center").pack(side="left", padx=1)

class FleetScreen(ctk.CTkFrame):
    def __init__(self, parent, on_back):
        super().__init__(parent, fg_color="#1a1a1a")
        self.on_back = on_back
        self.data_service = DataService()
        self.aircraft_data = None
        
        data = self.data_service.load_data()
        self.tail_numbers = list(data.get("fleet", {}).keys())
        if not self.tail_numbers: self.tail_numbers = ["661", "662", "663", "665", "667", "668", "669"]

        # Top Bar
        top = ctk.CTkFrame(self, fg_color="#333", height=50)
        top.pack(fill="x", padx=10, pady=10)
        ctk.CTkButton(top, text="<< Back", width=80, command=on_back, fg_color="#555").pack(side="left", padx=10)
        # תיקון קריסה:
        ctk.CTkLabel(top, text="Fleet Manager", font=("Arial", 20, "bold")).pack(side="left", expand=True) 
        ctk.CTkButton(top, text="Save All", width=80, fg_color="green", command=self.save_all).pack(side="right", padx=10)

        # Layout
        main = ctk.CTkFrame(self, fg_color="transparent")
        main.pack(fill="both", expand=True, padx=10, pady=5)

        # Left Column
        left_col = ctk.CTkFrame(main, width=240)
        left_col.pack(side="left", fill="y", padx=5)
        
        ctk.CTkLabel(left_col, text="Aircraft List", font=("Arial", 14, "bold")).pack(pady=5)
        self.ac_scroll = ctk.CTkScrollableFrame(left_col, height=200)
        self.ac_scroll.pack(fill="x", pady=5)
        for t in self.tail_numbers:
            ctk.CTkButton(self.ac_scroll, text=t, fg_color="#444", hover_color="#666", command=lambda x=t: self.load_tail(x)).pack(fill="x", pady=2)

        ctk.CTkLabel(left_col, text="Weighing Data", font=("Arial", 14, "bold"), text_color="orange").pack(pady=(20, 5))
        self.en_tail = self._entry(left_col, "Tail:")
        self.en_ww = self._entry(left_col, "Weight:")
        self.en_wa = self._entry(left_col, "Arm:")
        self.en_wm = self._entry(left_col, "Moment:")
        ctk.CTkButton(left_col, text="Update Weighing", fg_color="#444", command=self.save_current).pack(pady=10)

        # Right Column
        right_col = ctk.CTkFrame(main, fg_color="transparent")
        right_col.pack(side="right", fill="both", expand=True, padx=5)

        ctk.CTkLabel(right_col, text="2. CONFIGURATION (REMOVALS)", font=("Arial", 12, "bold"), anchor="w").pack(fill="x")
        self.table_config = ExcelTable(right_col, ["Item Name", "Unit Wt", "Max", "Actual", "Removed", "Rem Wt"], [180, 60, 40, 90, 60, 70])
        self.table_config.pack(fill="both", expand=True, pady=5)

        ctk.CTkLabel(right_col, text="3. STRUCTURAL UPDATES", font=("Arial", 12, "bold"), anchor="w").pack(fill="x", pady=(10,0))
        self.table_updates = ExcelTable(right_col, ["Date", "Adjuster", "Description", "Weight", "Moment"], [70, 70, 180, 60, 60])
        self.table_updates.pack(fill="both", expand=True, pady=5)

        bot = ctk.CTkFrame(right_col, fg_color="#222", height=40, border_color="green", border_width=2)
        bot.pack(fill="x", pady=10)
        self.lbl_summary = ctk.CTkLabel(bot, text="SELECT AIRCRAFT", font=("Arial", 18, "bold"))
        self.lbl_summary.pack(pady=5)

        if self.tail_numbers: self.load_tail(self.tail_numbers[0])

    def _entry(self, p, t):
        f = ctk.CTkFrame(p, fg_color="transparent"); f.pack(fill="x", pady=1)
        ctk.CTkLabel(f, text=t, width=60, anchor="w").pack(side="left")
        e = ctk.CTkEntry(f); e.pack(side="right", fill="x", expand=True)
        return e

    def load_tail(self, tail):
        self.aircraft_data = self.data_service.get_aircraft(tail)
        self.en_tail.delete(0,"end"); self.en_tail.insert(0, self.aircraft_data.tail_number)
        self.en_ww.delete(0,"end"); self.en_ww.insert(0, str(self.aircraft_data.weighing_weight))
        self.en_wa.delete(0,"end"); self.en_wa.insert(0, str(self.aircraft_data.weighing_arm))
        self.en_wm.delete(0,"end"); self.en_wm.insert(0, str(self.aircraft_data.weighing_moment))
        self.render_tables()

    def render_tables(self):
        ac = self.aircraft_data
        c_rows, total_rem = [], 0
        for item in ac.config_items:
            rem = item.full_qty - item.qty_in_plane
            rem_w = rem * item.weight_per_unit
            total_rem += rem_w
            col = "red" if rem > 0 else "gray"
            c_rows.append({"values": [item.name, item.weight_per_unit, item.full_qty, item.qty_in_plane, rem, f"{rem_w:.1f}"],
                           "colors": ["white", "white", "gray", "white", col, col], "ref": item})
        self.table_config.set_data(c_rows, callback=self.on_config_change)

        u_rows, total_upd = [], 0
        for u in ac.update_items:
            total_upd += u.weight_change
            col = "green" if u.weight_change >= 0 else "red"
            u_rows.append({"values": [u.date, u.adjuster, u.description, u.weight_change, u.moment_change],
                           "colors": ["white", "white", "white", col, "white"]})
        self.table_updates.set_data(u_rows)

        basic = ac.weighing_weight - total_rem + total_upd
        self.lbl_summary.configure(text=f"BASIC WEIGHT: {int(basic):,} Lbs  (Rem: -{int(total_rem)} | Upd: {int(total_upd)})")

    def on_config_change(self, item, delta):
        new_val = item.qty_in_plane + delta
        if 0 <= new_val <= item.full_qty:
            item.qty_in_plane = new_val
            self.render_tables()

    def save_current(self):
        if self.aircraft_data:
            try:
                self.aircraft_data.tail_number = self.en_tail.get()
                self.aircraft_data.weighing_weight = float(self.en_ww.get())
                self.aircraft_data.weighing_arm = float(self.en_wa.get())
                self.aircraft_data.weighing_moment = float(self.en_wm.get())
                self.data_service.save_aircraft(self.aircraft_data)
                self.render_tables()
            except: pass
    def save_all(self): self.save_current()