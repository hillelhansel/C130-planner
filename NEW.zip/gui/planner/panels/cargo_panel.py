import customtkinter as ctk
from gui.planner.panels.base_panel import BasePanel
from gui.planner.panels.catalog_popup import CatalogPopup
from core.models import CargoItem
from core.constants import COMPARTMENT_DEFS

class CargoPanel(BasePanel):
    def __init__(self, parent, mgr, on_edit_request):
        super().__init__(parent, "4. CARGO & PAYLOAD", mgr, start_open=True)
        self.on_edit_request = on_edit_request
        
        # הגדרות מקוריות
        self.PRESETS = {
            "General": {"l": 0, "w": 0, "wt": 0},
            "Passenger": {"l": 20, "w": 20, "wt": 240},
            "463L Master": {"l": 108, "w": 88, "wt": 2500},
            "463L Crosswise": {"l": 88, "w": 108, "wt": 2500},
            "CDS Bundle": {"l": 48, "w": 48, "wt": 2200},
            "Heavy Equp": {"l": 120, "w": 80, "wt": 5000}
        }

        # UI
        r1 = ctk.CTkFrame(self.content, fg_color="transparent"); r1.pack(fill="x", pady=2)
        self.type_var = ctk.StringVar(value="General")
        ctk.CTkComboBox(r1, values=list(self.PRESETS.keys()), width=120, variable=self.type_var, command=self.on_type).pack(side="left", padx=2)
        
        self.comp_var = ctk.StringVar(value="Manual")
        comps = ["Manual"] + [c[0] for c in COMPARTMENT_DEFS]
        ctk.CTkComboBox(r1, values=comps, width=80, variable=self.comp_var, command=self.on_comp).pack(side="left", padx=2)

        r2 = ctk.CTkFrame(self.content, fg_color="transparent"); r2.pack(fill="x", pady=2)
        self.en_name = self._mk(r2, "Name", 80)
        self.en_wt = self._mk(r2, "Wt", 50)
        self.en_st = self._mk(r2, "St", 50)

        r3 = ctk.CTkFrame(self.content, fg_color="transparent"); r3.pack(fill="x", pady=2)
        self.en_len = self._mk(r3, "L", 40)
        self.en_wid = self._mk(r3, "W", 40)
        ctk.CTkButton(r3, text="ADD", width=50, fg_color="green", command=self.add).pack(side="right", padx=5)
        
        ctk.CTkButton(self.content, text="Open Catalog", height=24, fg_color="#3B8ED0", command=self.open_cat).pack(fill="x", pady=5, padx=5)
        self.scroll = ctk.CTkScrollableFrame(self.content, height=180); self.scroll.pack(fill="both", expand=True)

    def _mk(self, p, ph, w):
        e = ctk.CTkEntry(p, placeholder_text=ph, width=w); e.pack(side="left", padx=1)
        return e

    def on_type(self, c):
        d = self.PRESETS.get(c, {})
        if c != "General": self.en_name.delete(0,"end"); self.en_name.insert(0, c)
        if d.get("wt"): self.en_wt.delete(0,"end"); self.en_wt.insert(0, str(d["wt"]))
        self.en_len.delete(0,"end"); self.en_len.insert(0, str(d["l"]))
        self.en_wid.delete(0,"end"); self.en_wid.insert(0, str(d["w"]))

    def on_comp(self, c):
        if c == "Manual": return
        for n, s, e in COMPARTMENT_DEFS:
            if n == c:
                self.en_st.delete(0,"end"); self.en_st.insert(0, str(int((s+e)/2)))
                break

    def add(self):
        try:
            item = CargoItem(self.en_name.get(), float(self.en_wt.get()), float(self.en_st.get()),
                             float(self.en_len.get() or 0), float(self.en_wid.get() or 0), self.type_var.get())
            self.mgr.add_cargo(item)
            self.en_name.delete(0,"end"); self.en_wt.delete(0,"end")
        except: pass

    def update_view(self, data):
        for w in self.scroll.winfo_children(): w.destroy()
        for i, item in enumerate(self.mgr.payload):
            f = ctk.CTkFrame(self.scroll, fg_color="#333", height=25); f.pack(fill="x", pady=1)
            btn = ctk.CTkButton(f, text=f"{item.name} ({int(item.weight)}) @ {item.station}", anchor="w", fg_color="transparent", height=20, hover_color="#444",
                                command=lambda x=item, idx=i: self.on_edit_request(x, 'cargo', idx))
            btn.pack(side="left", fill="x", expand=True)
            ctk.CTkButton(f, text="X", width=25, height=20, fg_color="transparent", text_color="red", command=lambda idx=i: self.mgr.remove_payload(idx)).pack(side="right")

    def open_cat(self): CatalogPopup(self, self.on_cat)
    def on_cat(self, n, w, s): self.mgr.add_cargo(CargoItem(n, w, float(self.en_st.get()) if self.en_st.get() else s))