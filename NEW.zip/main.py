# main.py
from gui.app_window import AppWindow

if __name__ == "__main__":
    app = AppWindow()
    app.mainloop()