from dataclasses import dataclass, field
from typing import List
from core.models import CrewMember, CargoItem
from services.data_service import DataService
from services.calc_service import CalculationService

@dataclass
class PlanState:
    name: str
    fuel_weight: float = 30000.0
    crew: List[CrewMember] = field(default_factory=list)
    payload: List[CargoItem] = field(default_factory=list)

class MissionManager:
    def __init__(self, tail_number="661"):
        self.data_service = DataService()
        self.tail_number = tail_number
        self.aircraft = self.data_service.get_aircraft(tail_number)
        
        self.plans: List[PlanState] = [PlanState("Leg 1")]
        self.active_index = 0
        self._observers = []
        
        # אתחול ראשוני
        self._init_default_crew()

    @property
    def active_plan(self) -> PlanState:
        return self.plans[self.active_index]

    @property
    def fuel_weight(self): return self.active_plan.fuel_weight
    @property
    def crew(self): return self.active_plan.crew
    @property
    def payload(self): return self.active_plan.payload

    def _init_default_crew(self):
        """ממלא את הצוות בתפקידי מפתח אם הרשימה ריקה"""
        if not self.active_plan.crew:
            defaults = [
                ("Pilot", 200, 200),
                ("Co-Pilot", 200, 200),
                ("Navigator", 200, 200),
                ("Loadmaster", 200, 245)
            ]
            for name, wt, st in defaults:
                self.active_plan.crew.append(CrewMember(name, wt, st, fixed=True))

    # --- ניהול תכניות (Legs) ---
    def get_plan_names(self): return [p.name for p in self.plans]
    
    def set_active_plan(self, index):
        if 0 <= index < len(self.plans):
            self.active_index = index
            self.notify()

    def add_plan(self, name):
        # יצירת תוכנית חדשה עם דלק זהה לנוכחית
        new_plan = PlanState(name, fuel_weight=self.active_plan.fuel_weight)
        self.plans.append(new_plan)
        self.active_index = len(self.plans) - 1
        
        # אתחול צוות גם ללג החדש
        self._init_default_crew()
        self.notify()

    def rename_active_plan(self, new_name):
        self.active_plan.name = new_name
        self.notify()

    # --- פעולות על המשימה ---
    def set_fuel(self, weight):
        self.active_plan.fuel_weight = weight
        self.notify()

    def add_crew(self, name, weight, station, count=1):
        self.active_plan.crew.append(CrewMember(name, weight, station, count))
        self.notify()

    def update_crew(self, index, name, weight, station, count):
        if 0 <= index < len(self.active_plan.crew):
            c = self.active_plan.crew[index]
            c.name = name; c.weight = weight; c.station = station; c.count = count
            self.notify()

    def remove_crew(self, index):
        if 0 <= index < len(self.active_plan.crew):
            self.active_plan.crew.pop(index)
            self.notify()

    def add_cargo(self, item: CargoItem):
        self.active_plan.payload.append(item)
        self.notify()

    def update_cargo(self, index, item: CargoItem):
        if 0 <= index < len(self.active_plan.payload):
            self.active_plan.payload[index] = item
            self.notify()

    def remove_payload(self, index):
        if 0 <= index < len(self.active_plan.payload):
            self.active_plan.payload.pop(index)
            self.notify()

    # --- חישובים ועדכונים ---
    def subscribe(self, callback):
        self._observers.append(callback)

    def notify(self):
        totals = self.calculate_current_state()
        for callback in self._observers:
            callback(self, totals)

    def calculate_current_state(self):
        # 1. משקל בסיס (כולל הסרות ועדכונים מהמודל)
        total_w = self.aircraft.basic_weight
        total_m = self.aircraft.basic_moment_raw
        
        # 2. צוות
        for c in self.active_plan.crew:
            w = c.weight * c.count
            total_w += w
            total_m += (w * c.ls)
        op_w = total_w
        
        # 3. מטען
        for p in self.active_plan.payload:
            total_w += p.weight
            total_m += p.moment
        zfw = total_w
        
        # 4. דלק
        tanks = CalculationService.distribute_fuel(self.active_plan.fuel_weight)
        fuel_w = sum(tanks.values())
        fuel_m = 0
        for tank, amount in tanks.items():
            fuel_m += CalculationService.get_fuel_moment(tank, amount) * 1000
            
        gw = zfw + fuel_w
        tm = total_m + fuel_m
        
        cg = tm / gw if gw > 0 else 0
        mac = CalculationService.calculate_mac(cg)
        
        return {
            "basic_w": self.aircraft.basic_weight,
            "op_w": op_w, 
            "zfw": zfw, 
            "fuel_w": fuel_w, 
            "gw": gw,
            "cg": cg, 
            "mac": mac, 
            "tanks": tanks,
            "plan_name": self.active_plan.name
        }